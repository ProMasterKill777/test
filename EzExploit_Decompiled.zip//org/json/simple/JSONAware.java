package org.json.simple;

public interface JSONAware {
   String toJSONString();
}
